def function_init():
    print("Successfully imported the init.py")