import time        
        
Passcode_list={
    'churn':'1'
    ,'poisson':'2'
    ,'tenet':'3'
    ,'mustang':'4'
    ,'figo':'5'
    ,'dropfirst':'6'
    ,'playstore':'7'
    ,'google':'8'
    ,'datatype':'9'
    ,'statquest':'10'
    ,'databricks':'11'
    ,'windows':'12'
    ,'apple':'13'
    ,'physics':'14'
    ,'prize':'15'
    ,'london':'16'
    ,'queen':'17'
    ,'blockchain':'18'
    ,'timestone':'19'
    ,'glitch':'20'
    }

Crossword_clues={
    '1':"""Add "ing" to the secret of energy and you get this algorithm""",
    '2':""" Guess the DataScience concept from 2 of the words in the sentence below
    He gave a very fitting reply. What do you think? Is it over?""",
    '3': """ 
    Sodium + Kick off H from Bee's home + region in West California, generally consisting of the counties surrounding San Francisco + 'es'
    """,
    '4': """ 
    The only machine learning algorithm that sounds like an actual machine
    """,
    '5': """ 
    Helps in linear transformations - ____vectors/values
    """,
    '6': """ 
    A fielder drops the ball and a batsman is out?? This concept might not work in Cricket but seems to work in Deep learning.
    """,
    '7': """ 
    This is a library used in Deep learning that sounds like Kamalhaasan's party's Symbol
    """,
    '8': """ 
    The idea is to go with the flow of wind in the cloud to manage workflows
    """,
    '9': """ 
      Add a dimension to the cube and you will receive a containment vessel to carry one of the stones in marvel that can be used to read text from images
    """,
    '10':""" 
      After preprocessing you remove the letter "F" as an outlier from this word and it sounds like a "Black bird" in tamil. Used to store, read and analyse real time streamig data
    """,
  '11':"""
Safety measure for hands. Used to encode your words
  """,
  '12':""" 
The car manufacturer cleared the confusion with the customers after he did this when he found a defect in the cars sold
  """,
  '13': """
Kid : This stuffed yellow soft toy is mine. 
Person : Who is your dad? 
Kid: Mr.Cutting
The toy made its mark in the world of business and technology in 2006
  """,
  '14':""" 
  I am an endangered species. Only 2000 odd friends are left in my species. I use my "Kumfu skills" to slice and dice data and help you out in all sorts of data manipulation. 
  """,
  '15':"""
Sherlock holmes was concerned that he had a few missing clues in a case. His immediate Neighbors helped him in filling up the missing pieces. Guess the algorithm.
  """,
  '16':"""
Twentieth century English mathematician; also, imitation game
  """,
  "17": """
I am the Universe arranged in a complex, orderly manner. 
You don't know how to "select star". Never mind. You can still view my data. Who am I?
  """,
  '18': """
Input: "Gandhiji was born in Porbandar. This is just to confuse. Did you know that there are many universties which are named after him?.This can be ignored. He indeed helped a lot many to come up"
Processing : You run the above  input corpus of text through a text processing library which tags the Parts of Speech (POS) for you. 
Output: All the first letters of the POS tagged as Common/Proper Nouns tells you what it can do to huge datasets.
  """,
  '19': """
I don't need supervision
I have a vision
Seggregation is my mission
Apples into Apples bucket
Oranges into Oranges bucket
Mangoes into Mangoes bucket
Which algorithm am I?
  """,
  '20':"""
Cost; Measure to determine "how BLEH the model is"
  """
    }

URL_clues={
    '1':"""
      The below link has a word that we are looking for
      https://www.investopedia.com/tech/most-important-cryptocurrencies-other-than-bitcoin/

      The word also has a relationship with the below link
      https://www.investopedia.com/terms/d/distributed-ledgers.asp
    """,
    '2': """
      The below link has a word that we are looking for
      https://docs.aws.amazon.com/sagemaker/latest/dg/whatis.html

      It is a feature used like a self driving feature in modeling
    """,
    '3':"""
    The below link has a word that we are looking for
    https://mode.com/blog/python-data-visualization-libraries/

    The word has a relationship with the below link
    https://uxplanet.org/crisis-in-the-flower-market-a-case-study-pt-i-d306161205a4
    """,
    '4': """
    The below link has a word that we are looking for
    https://joshdance.medium.com/audio-drop-in-social-networks-report-445f97b5f5d3

    The word has a relationship with the below link
    https://www.tripstodiscover.com/9-unforgettable-hotels-resorts-in-india/
    """,
    '5': """
      The below link has a word that we are looking for

      https://cricnerds.com/cricket-terms-and-rules/decision-review-system-drs-in-cricket/

      The word functions like the below implementation

      https://timsainburg.com/noise-reduction-python.html 
    """,
    '6':"""
      Link: https://towardsdatascience.com/9-distance-measures-in-data-science-918109d069fa

      Clue: Distance between 2 points measured along the surface of the earth
    """,
    '7':"""
      Link: https://machinelearningmastery.com/introduction-to-regularization-to-reduce-overfitting-and-improve-generalization-error/

      Clue: When yellow light glows before red light
    """,
    '8':"""
    Link: https://medium.com/@IliyanaStareva/8-step-framework-to-problem-solving-from-mckinsey-506823257b48

    Clue: Exclusivity comes together to make it complete
    """,
    '9':"""
    Link: https://trailhead.salesforce.com/content/learn/modules/starting_force_com

    Clue: This platform integrates all the essential functions of an organization under a single umbrella which is otherwise called as
    """,
    '10':"""
     Link: https://cs231n.github.io/neural-networks-3/

     Clue: Adding momentum to one another existing adaptive technique in Gradient Descent
    """,
    '11':"""
      Link: https://docs.scrapy.org/en/latest/intro/examples.html

      Clue: These classes describe how a website can be scraped
    """,
    '12':"""
    Link: https://docs.microsoft.com/en-in/azure/devops/pipelines/?view=azure-devops

    Clue: To automate build, test and delivery you need to define pipelines in this file
    """,
    '13': """
    Link: https://keras.io/guides/

    Clue: Except for BatchNormalization layer in Keras, all layers have trainable weights only. Intentionally, these trainable weights are set to non-trainable to freeze these layers to utlize these pre-trained layers. For what purpose is this done?
    """,
    '14': """
      We're looking for the word related to the below link
      https://sparkar.facebook.com/ar-studio/learn/

      It is also a 'village' where millennials live
    """,
    '15':"""
    The below link has a word that we are looking for:
      https://www.analyticsvidhya.com/blog/2016/02/time-series-forecasting-codes-python/

      Anagram for the word looks like:

        ENIFEFRCNDIG
    """,
    '16':"""
      The below link has a word that we are looking for:

https://towardsdatascience.com/ai-powered-business-decision-making-111c06750488

Anagram for the word looks like:

TMONIZOTIPIA
    """,
    '17':"""
      The below link has a word that we are looking for:

        https://towardsdatascience.com/dimensionality-reduction-of-a-color-photo-splitting-into-rgb-channels-using-pca-algorithm-in-python-ba01580a1118
      
      Anagram for the word looks like:

    INUEAEGLVE
    """,
    '18':"""
      The below link has a word that we are looking for:

https://towardsdatascience.com/model-validation-and-monitoring-new-phases-in-the-ml-lifecycle-1c57b86c9aa
      
Anagram for the word looks like:

AYTIEAPXILBLNI
    """,
    '19':"""
        The below link has a word that we are looking for:

https://www.analyticsvidhya.com/blog/2016/08/beginners-guide-to-topic-modeling-in-python/
      
Anagram for the word looks like:

IMESGN
    """,
    '20':"""
        The below link has a word that we are looking for:

https://jalammar.github.io/illustrated-gpt2/
      
Anagram for the word looks like:

RSRNRFAOEMT
    """
}



URL_Answers={
    '1': ['blockchain'],
    '2':['Autopilot'],
    '3':['Bokeh'],
    '4':['clubhouse'],
    '5':['snickometer','ultraedge','snicko'],
    '6':['Great Circle','geodesic'],
    '7':['Early Stopping', 'Earlystopping'],
    '8':['MECE'],
    '9':['CRM'],
    '10':['ADAM'],
    '11':['Spider'],
    '12':['YAML'],
    '13':['Transfer Learning', 'Transferlearning'],
    '14':['instagram'],
    '15':['Differencing'],
    '16':['Optimization'],
    '17':['Eigenvalue'],
    '18':['Explainability'],
    '19':['Gensim'],
    '20':['Transformer']
}

Crossword_Order={
    '1':'8D',
    '2':'1D',
    '3':'11A',
    '4':'9A',
    '5':'5A',
    '6':'18A',
    '7':'2A',
    '8':'7A',
    '9':'10A',
    '10':'15A',
    '11':'13A',
    '12':'4D',
    '13':'12D',
    '14':'2D',
    '15':'15D',
    '16':'3D',
    '17':'6D',
    '18':'17D',
    '19':'16A',
    '20':'14D'
}

def upper(txt):
    return txt.upper()

def check_the_url_answer(passcode,val):
    string_list = [each_string.upper() for each_string in URL_Answers[Passcode_list[passcode]]]
    if upper(val) in string_list:
        return False
    else:
        return True
    
def follow_the_trail(passcode):
    if passcode in Passcode_list.keys():
        print('Passcode is valid!')
        time.sleep(2.1)
        print('Please solve the below puzzle to get the crossword clue')
        time.sleep(2.1)
        print(URL_clues[Passcode_list[passcode]])
        val=input("Can you type it here:")
        while(check_the_url_answer(passcode,val)):
            print("That is not what I'm looking for")
            val=input("Try Again:")
        time.sleep(1.8)
        print("Crossword clue for the Grid Position:",Crossword_Order[Passcode_list[passcode]])
        print('Crossword clue is')
        time.sleep(2.1)
        print(Crossword_clues[Passcode_list[passcode]])
    else:
        print("Incorrect Passcode. Please Try again later")    
        