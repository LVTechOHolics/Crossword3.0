def evaluate1(df, key):
    if df.shape == (5,3) and key == "zip":
        return print("CODE: churn")
    else:
        return print("Sorry!, wrong answer.")
    
def evaluate2(first, second):
    if first=="random" and second in ("randn", "normal"):
        print("CODE: poisson")
    else:
        print("Sorry!, wrong answer")

def evaluate3(fn):
    if fn("tenet"):
        print("CODE: tenet")
    else:
        print("Sorry!, wrong answer")  
        
def evaluate4(df):
    if df.shape == (51,1):
        print("CODE 1: mustang")
        print("CODE 2: figo")
    else:
        print("Sorry!, wrong answer")            
        
def evaluate5(df):
    if df.shape == (344, 9):
        print("CODE: dropfirst")
    else:
        print("Sorry!, wrong answer")   
        
def evaluate6(blank1, blank2, blank3):
    if blank1 == "str" and blank2 == "replace" and blank3 == "astype":
        print("CODE 1: playstore")
        print("CODE 2: google")
    else:
        print("Sorry!, wrong answer")   
        
def evaluate7(blank):
    if blank == "select_dtypes":
        print("CODE: datatype")
    else:
        print("Sorry!, wrong answer")         
        
def evaluate8(blank):
    if blank == "np.where":
        print("CODE 1: statquest")
        print("CODE 2: databricks")
    else:
        print("Sorry!, wrong answer")        
        
def evaluate9(blank):
    if blank == "transform":
        print("CODE 1: windows")
        print("CODE 2: apple")
    else:
        print("Sorry!, wrong answer")  
        
def evaluate10(blank):
    if blank == "nsmallest":
        print("CODE 1: physics")
        print("CODE 2: prize")
    else:
        print("Sorry!, wrong answer") 

def evaluate11(blank1, blank2):
    if blank1 == "filter" and blank2 == "count":
        print("CODE 1: london")
        print("CODE 2: queen")
    else:
        print("Sorry!, wrong answer")        
        
def evaluate12(blank1, blank2):
    if blank1 == "corr" and blank2 == "0":
        print("CODE: abracadabra")
    else:
        print("Sorry!, wrong answer")         
        
def evaluate13(blank1, blank2, blank3, blank4):
    if blank1=="pd" and blank2=="to_datetime" and blank3=="dt" and blank4=="month":
        print("CODE: timestone")
    else:
        print("Sorry!, wrong answer") 

def evaluate14(blank1, blank2, blank3):
    if blank1=="zeros" and blank2=="ones" and blank3=="identity":
        print("CODE: glitch")
    else:
        print("Sorry!, wrong answer")     
        